package csd.uoc.gr.A21;

import csd.uoc.gr.A21.Sensors.*;

//auto trexei tin ASK 1
class SensorTester {
    public static void main(String[] args) {
        System.out.println("\n---- ερωτημα α");

        System.out.println(new Sensor("S01", false, false));
        System.out.println(new TemperatureSensor("S02", false, false));
        System.out.println(new LaserSensor("S03", false, false, 4F));

        //erwthma b
        System.out.println("\n---- ερωτημα β");
        SensorLine line = new SensorLine();
        line.addSensor(new Sensor("S01", false, false));
        line.addSensor(new LaserSensor("S02", true, false, 4F));
        System.out.println(line);

        //erwthma c
        System.out.println("\n---- ερωτημα γ");
        SensorLine line2 = new SensorLine();
        for (int i = 0; i < 100; i++) {
            String id = "SID" + i;
            boolean state = false;
            if (i%4 == 0){
                state = true;
            }

            if (i%3 == 0){
                line2.addSensor(new Sensor(id, state, false));
            }
            else if (i%3 == 1){
                line2.addSensor(new TemperatureSensor(id, state, false));
            }
            else if (i%3 == 2){
                line2.addSensor(new LaserSensor(id,state, false, i*1F));
            }
        }

        System.out.println(line2);
    }
}

