package csd.uoc.gr.A22;

import csd.uoc.gr.A21.Sensors.*;
import csd.uoc.gr.A21.SensorLine;

public class ask2 {
    public static void main(String[] args){
        //create sensors
        Sensor inSensor1 = new Sensor("IS01", false, false);
        LaserSensor inSensor2 = new LaserSensor("IS02", false, false, 4F);
        TemperatureSensor inSensor3 = new TemperatureSensor("IS03", false, false);
        Sensor inSensor4 = new Sensor("IS04", false, false);
        LaserSensor inSensor5 = new LaserSensor("IS05", false, false, 5F);

        Sensor exSensor1 = new Sensor("ES01", false, false);
        Sensor exSensor2 = new Sensor("ES02", false, false);
        LaserSensor exSensor3 = new LaserSensor("ES03", false, false, 4F);
        Sensor exSensor4 = new Sensor("ES04", false, false);
        LaserSensor exSensor5 = new LaserSensor("ES05", false, false, 3F);

        //create sensorline objects
        SensorLine inLine1 = new SensorLine();
        SensorLine inLine2 = new SensorLine();
        SensorLine inLine3 = new SensorLine();

        SensorLine exLine1 = new SensorLine();
        SensorLine exLine2 = new SensorLine();

        //ta kanw populate
        inLine1.addSensor(inSensor1);
        inLine1.addSensor(inSensor2);
        inLine2.addSensor(inSensor3);
        inLine3.addSensor(inSensor4);
        inLine3.addSensor(inSensor5);

        exLine1.addSensor(exSensor1);
        exLine1.addSensor(exSensor2);
        exLine1.addSensor(exSensor3);
        exLine2.addSensor(exSensor4);
        exLine2.addSensor(exSensor5);
        //create arrays

        SensorLine[] inLines = {inLine1, inLine2, inLine3};
        SensorLine[] exLines = {exLine1, exLine2};

        //use hsadt constructor
        HomeSecurityADT security = new HomeSecurityADT(inLines, exLines);
        try {
            security.arm();
            security.disarm();
            security.changePw();
            security.stay();
            security.disarm();
        }catch (Exception e) {}

    }
}
